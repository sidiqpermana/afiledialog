/** Automatically generated file. DO NOT MODIFY */
package ar.com.daidalos.afiledialog.test;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}